<?php

  $config = array(
    
    'database' => array(
      'host' => 'localhost',
      'username' => 'dev',
      'password' => 'mysql',
      'database' => 'GALLERY2',
      'encoding' => 'utf8',
    ),
  );